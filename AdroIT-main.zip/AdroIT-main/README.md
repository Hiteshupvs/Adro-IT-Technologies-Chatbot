1. Install Flask
To get started with this Flask application, first, make sure you have Python installed. Then, install Flask using the following command in your terminal or command prompt:
pip install Flask

2. I) Copy the Files into a Single Folder (Eduvate chatbot)
Create a new folder on your computer 
Inside this folder, create the following files and copy the respective contents into them:
1. app1.py
2. index1.html

II) Copy the Files into a Single Folder (Prolearn chatbot)
Create a new folder on your computer 
Inside this folder, create the following files and copy the respective contents into them:
1. app2.py
2. index2.html

3. I) Run the Application
Once you've copied all the files into a single folder, follow these steps to run the application:
Open the Command Prompt (Windows)
Navigate to the folder where you saved the files:
cd path/to/your/folder
python app1.py
Open a web browser and visit the following URL to start chatting with the bot:
http://127.0.0.1:3000/

II) Run the Application
Once you've copied all the files into a single folder, follow these steps to run the application:
Open the Command Prompt (Windows)
Navigate to the folder where you saved the files:
cd path/to/your/folder
python app2.py
Open a web browser and visit the following URL to start chatting with the bot:
http://127.0.0.1:3000/
